<template>
  <div class="list-container">
    <h1 class="page-title">闲置交易</h1>
    <p class="page-desc">功能开发中，敬请期待...</p>
  </div>
</template>

<script setup>
</script>

<style scoped>
.list-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 40px 20px;
  text-align: center;
}

.page-title {
  font-size: 28px;
  font-weight: bold;
  color: #303133;
  margin: 0 0 16px 0;
}

.page-desc {
  font-size: 16px;
  color: #606266;
}
</style>

