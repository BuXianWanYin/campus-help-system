<template>
  <div class="login-container">
    <!-- 左侧：插图和宣传文字 -->
    <div class="login-left">
      <div class="illustration-wrapper">
        <div class="system-title">{{ appConfig.title }}</div>
        <div class="feature-cards">
          <div class="feature-card">
            <div class="feature-icon">
              <el-icon :size="40"><Search /></el-icon>
            </div>
            <div class="feature-title">失物招领</div>
            <div class="feature-desc">发布失物信息<br/>寻找丢失物品</div>
          </div>
          <div class="feature-card">
            <div class="feature-icon">
              <el-icon :size="40"><ShoppingBag /></el-icon>
            </div>
            <div class="feature-title">闲置交易</div>
            <div class="feature-desc">买卖闲置物品<br/>让资源再利用</div>
          </div>
          <div class="feature-card">
            <div class="feature-icon">
              <el-icon :size="40"><Box /></el-icon>
            </div>
            <div class="feature-title">跑腿服务</div>
            <div class="feature-desc">发布或接取任务<br/>互帮互助</div>
          </div>
        </div>
        <div class="promo-text">
          <h1>连接校园，互助共享</h1>
          <p>失物招领、闲置交易、跑腿服务，一站式解决您的校园互助需求</p>
        </div>
      </div>
    </div>
    
    <!-- 右侧：登录表单 -->
    <div class="login-right">
      <div class="login-form-wrapper">
        <h1 class="form-title">欢迎回来</h1>
        <p class="form-subtitle">输入您的邮箱和密码登录</p>
        
        <el-form
          ref="loginFormRef"
          :model="loginForm"
          :rules="loginRules"
          class="login-form"
        >
          <el-form-item prop="email">
            <el-input
              v-model="loginForm.email"
              placeholder="请输入邮箱"
              size="large"
            >
              <template #prefix>
                <el-icon><Message /></el-icon>
              </template>
            </el-input>
          </el-form-item>
          
          <el-form-item prop="password" v-if="loginType === 'password'">
            <el-input
              v-model="loginForm.password"
              type="password"
              placeholder="请输入密码"
              size="large"
              show-password
              @keyup.enter="handleLogin"
            >
              <template #prefix>
                <el-icon><Lock /></el-icon>
              </template>
            </el-input>
          </el-form-item>
          
          <el-form-item prop="code" v-if="loginType === 'code'">
            <el-input
              v-model="loginForm.code"
              placeholder="请输入验证码"
              size="large"
              @keyup.enter="handleLogin"
            >
              <template #prefix>
                <el-icon><Key /></el-icon>
              </template>
              <template #append>
                <el-button
                  :disabled="codeCountdown > 0 || codeSending"
                  :loading="codeSending"
                  @click="sendLoginCode"
                >
                  {{ codeSending ? '发送中' : (codeCountdown > 0 ? `${codeCountdown}秒` : '获取验证码') }}
                </el-button>
              </template>
            </el-input>
          </el-form-item>
          
          <div class="form-options">
            <div style="display: flex; justify-content: space-between; width: 100%;">
              <el-link
                type="primary"
                :underline="false"
                @click="toggleLoginType"
                class="toggle-link"
              >
                {{ loginType === 'password' ? '使用验证码登录' : '使用密码登录' }}
              </el-link>
              <el-link
                v-if="loginType === 'password'"
                type="primary"
                :underline="false"
                @click="goToForgotPassword"
                class="toggle-link"
              >
                忘记密码？
              </el-link>
            </div>
          </div>
          
          <el-form-item>
            <el-button
              type="primary"
              :loading="loginLoading"
              size="large"
              style="width: 100%"
              @click="handleLogin"
            >
              登录
            </el-button>
          </el-form-item>
          
          <div class="form-footer">
            <el-link
              type="primary"
              :underline="false"
              @click="goToRegister"
            >
              还没有账号？<span class="link-text">注册</span>
            </el-link>
          </div>
        </el-form>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onUnmounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { ElMessage } from 'element-plus'
import { Search, ShoppingBag, Box, Message, Lock, Key, Loading } from '@element-plus/icons-vue'
import { useUserStore } from '@/stores/user'
import { authApi } from '@/api'
import appConfig from '@/config'

const router = useRouter()
const route = useRoute()
const userStore = useUserStore()

const loginType = ref('password') // password 或 code
const loginLoading = ref(false)
const codeCountdown = ref(0)
const codeSending = ref(false)
const loginFormRef = ref(null)
let countdownTimer = null

const loginForm = reactive({
  email: '',
  password: '',
  code: ''
})

const loginRules = {
  email: [
    { required: true, message: '请输入邮箱', trigger: 'blur' },
    { type: 'email', message: '邮箱格式不正确', trigger: 'blur' }
  ],
  password: [
    { required: true, message: '请输入密码', trigger: 'blur' }
  ],
  code: [
    { required: true, message: '请输入验证码', trigger: 'blur' }
  ]
}

// 切换登录方式
const toggleLoginType = () => {
  loginType.value = loginType.value === 'password' ? 'code' : 'password'
  if (loginFormRef.value) {
    loginFormRef.value.clearValidate()
  }
}

// 发送登录验证码
const sendLoginCode = async () => {
  if (!loginForm.email) {
    ElMessage.warning('请先输入邮箱')
    return
  }
  
  if (codeCountdown.value > 0 || codeSending.value) {
    return
  }
  
  codeSending.value = true
  try {
    await authApi.sendCode('LOGIN', loginForm.email)
    ElMessage.success('验证码已发送，请查收邮件')
    startCountdown(60)
  } catch (error) {
    // 如果后端返回了剩余秒数，使用该秒数
    const remainingSeconds = extractRemainingSeconds(error.message || '')
    if (remainingSeconds > 0) {
      startCountdown(remainingSeconds)
    }
    ElMessage.error(error.message || '发送验证码失败')
  } finally {
    codeSending.value = false
  }
}

// 从错误信息中提取剩余秒数
const extractRemainingSeconds = (message) => {
  const match = message.match(/(\d+)秒后重试/)
  return match ? parseInt(match[1]) : 0
}

// 开始倒计时
const startCountdown = (seconds) => {
  // 清除之前的定时器
  if (countdownTimer) {
    clearInterval(countdownTimer)
  }
  codeCountdown.value = seconds
  countdownTimer = setInterval(() => {
    codeCountdown.value--
    if (codeCountdown.value <= 0) {
      clearInterval(countdownTimer)
      countdownTimer = null
    }
  }, 1000)
}

// 组件卸载时清理定时器
onUnmounted(() => {
  if (countdownTimer) {
    clearInterval(countdownTimer)
    countdownTimer = null
  }
})

// 处理登录
const handleLogin = async () => {
  if (!loginFormRef.value) return
  
  await loginFormRef.value.validate(async (valid) => {
    if (valid) {
      loginLoading.value = true
      try {
        const email = loginForm.email
        const password = loginType.value === 'password' ? loginForm.password : null
        const code = loginType.value === 'code' ? loginForm.code : null
        
        await userStore.login(email, password, code)
        ElMessage.success('登录成功')
        
        // 如果是管理员，跳转到管理后台；否则跳转到指定页面或首页
        if (userStore.isAdmin) {
          router.push('/admin/dashboard')
        } else {
          const redirect = route.query.redirect || '/'
          router.push(redirect)
        }
      } catch (error) {
        ElMessage.error(error.message || '登录失败')
      } finally {
        loginLoading.value = false
      }
    }
  })
}

// 跳转到注册页
const goToRegister = () => {
  router.push({ path: '/register', query: route.query })
}

// 跳转到忘记密码页
const goToForgotPassword = () => {
  router.push({ path: '/forgot-password', query: route.query })
}
</script>

<style scoped>
.login-container {
  display: flex;
  min-height: 100vh;
  background-color: #f7fbfc;
}

/* 左侧区域 */
.login-left {
  flex: 0 0 60%;
  background-color: #d6e6f2;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: 60px 80px;
  position: relative;
  overflow: hidden;
}

.illustration-wrapper {
  position: relative;
  width: 100%;
  max-width: 600px;
  z-index: 1;
}

.system-title {
  font-size: 42px;
  font-weight: bold;
  color: #303133;
  text-align: center;
  margin-bottom: 50px;
  letter-spacing: 2px;
}

.feature-cards {
  display: flex;
  justify-content: space-around;
  gap: 30px;
  margin-bottom: 60px;
}

.feature-card {
  flex: 1;
  background: rgba(255, 255, 255, 0.9);
  border-radius: 20px;
  padding: 30px 20px;
  text-align: center;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.feature-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 12px 32px rgba(0, 0, 0, 0.15);
}

.feature-icon {
  width: 80px;
  height: 80px;
  margin: 0 auto 20px;
  background: linear-gradient(135deg, #409eff 0%, #66b1ff 100%);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
}

.feature-title {
  font-size: 18px;
  font-weight: bold;
  color: #303133;
  margin-bottom: 10px;
}

.feature-desc {
  font-size: 14px;
  color: #606266;
  line-height: 1.6;
}

.promo-text {
  text-align: center;
}

.promo-text h1 {
  font-size: 36px;
  font-weight: bold;
  color: #303133;
  margin-bottom: 20px;
}

.promo-text p {
  font-size: 16px;
  color: #606266;
  line-height: 1.8;
}

/* 右侧区域 */
.login-right {
  flex: 0 0 40%;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #FFFFFF;
  padding: 40px;
}

.login-form-wrapper {
  width: 100%;
  max-width: 420px;
}

.form-title {
  font-size: 28px;
  font-weight: bold;
  color: #303133;
  margin: 0 0 8px 0;
}

.form-subtitle {
  font-size: 14px;
  color: #909399;
  margin: 0 0 32px 0;
}

.login-form {
  margin-top: 32px;
}

.login-form :deep(.el-form-item) {
  margin-bottom: 20px;
}

.login-form :deep(.el-input__wrapper) {
  border-radius: 4px;
  box-shadow: 0 0 0 1px #b9d7ea inset;
}

.login-form :deep(.el-input__wrapper:hover) {
  box-shadow: 0 0 0 1px #769fcd inset;
}

.login-form :deep(.el-input.is-focus .el-input__wrapper) {
  box-shadow: 0 0 0 1px #769fcd inset;
}

.form-options {
  display: flex;
  justify-content: flex-end;
  margin-bottom: 24px;
}

.toggle-link {
  font-size: 14px;
  color: #409eff;
}

.toggle-link:hover {
  color: #66b1ff;
}

.form-footer {
  text-align: center;
  margin-top: 24px;
  font-size: 14px;
  color: #606266;
}

.link-text {
  color: #409eff;
  font-weight: 500;
}

.form-footer .el-link:hover .link-text {
  color: #66b1ff;
}

/* 响应式设计 */
@media (max-width: 1024px) {
  .login-container {
    flex-direction: column;
  }
  
  .login-left {
    flex: 0 0 auto;
    padding: 40px 20px;
  }
  
  .feature-cards {
    flex-direction: column;
    gap: 20px;
  }
  
  .system-title {
    font-size: 32px;
    margin-bottom: 30px;
  }
  
  .promo-text h1 {
    font-size: 28px;
  }
  
  .login-right {
    padding: 20px;
  }
}
</style>
